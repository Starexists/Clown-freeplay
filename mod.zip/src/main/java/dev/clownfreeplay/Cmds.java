package dev.clownfreeplay;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.level.ServerPlayer;

final class Cmds {
    private Cmds() {}

    static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("clown")
                .executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Menu.open(c.getSource().getServer(), p);
                    return 1;
                })
                .then(Commands.literal("menu").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Menu.open(c.getSource().getServer(), p);
                    return 1;
                }))
                .then(Commands.literal("start")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Cfg.missionIds(), b))
                                .executes(c -> {
                                    ServerPlayer p = c.getSource().getPlayerOrException();
                                    Manager.start(c.getSource().getServer(), p, StringArgumentType.getString(c, "id"));
                                    return 1;
                                })))
                .then(Commands.literal("quit").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Manager.quit(c.getSource().getServer(), p);
                    return 1;
                }))
                .then(Commands.literal("ranks").executes(c -> {
                    Menu.ranks(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("kits").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Menu.kits(c.getSource().getServer(), p);
                    return 1;
                }))
                .then(Commands.literal("debug")
                        .then(Commands.literal("tokens")
                                .then(Commands.argument("n", IntegerArgumentType.integer(-1000, 1000))
                                        .executes(c -> {
                                            ServerPlayer p = c.getSource().getPlayerOrException();
                                            if (!Cfg.get().allowDebug) {
                                                Util.say(p, "Debug commands are off (allowDebug in the config).");
                                                return 0;
                                            }
                                            Data.Rec r = Data.rec(p.getUUID());
                                            r.tokens = Math.max(0, r.tokens + IntegerArgumentType.getInteger(c, "n"));
                                            Data.save();
                                            Util.say(p, "Tokens: " + r.tokens + " (rank " + Cfg.rankName(Cfg.rankOf(r.tokens)) + ")");
                                            return 1;
                                        })))));
    }
}
