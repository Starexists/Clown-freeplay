package dev.clownfreeplay;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/** Clickable chat menu. Tap the green buttons. */
final class Menu {
    private Menu() {}

    private static JsonObject click(String text, String color, String command, String hover) {
        JsonObject o = Util.text(text, color);
        JsonObject ce = new JsonObject();
        ce.addProperty("action", "run_command");
        ce.addProperty("command", command);
        o.add("click_event", ce);
        if (hover != null) {
            JsonObject he = new JsonObject();
            he.addProperty("action", "show_text");
            he.addProperty("value", hover);
            o.add("hover_event", he);
        }
        return o;
    }

    private static JsonObject bold(String t, String color) {
        JsonObject o = Util.text(t, color);
        o.addProperty("bold", true);
        return o;
    }

    static void open(MinecraftServer s, ServerPlayer p) {
        Cfg c = Cfg.get();
        Data.Rec rec = Data.rec(p.getUUID());
        int ri = Cfg.rankOf(rec.tokens);

        JsonArray a = new JsonArray();
        a.add(new JsonPrimitive(""));
        a.add(bold("=== CLOWN FREEPLAY ===\n", "gold"));
        a.add(Util.text("Rank: ", "gray"));
        a.add(bold(Cfg.rankName(ri), "yellow"));
        a.add(Util.text("   Tokens: " + rec.tokens, "gray"));
        if (ri + 1 < c.ranks.size()) {
            Cfg.Rank nx = c.ranks.get(ri + 1);
            a.add(Util.text("   (next: " + nx.name + " at " + nx.tokens + ")", "dark_gray"));
        } else {
            a.add(Util.text("   (max rank)", "dark_gray"));
        }
        a.add(Util.text("\n", "white"));

        section(a, "\nMissions\n", "aqua", c, false, ri, rec);
        section(a, "\nBig battles\n", "red", c, true, ri, rec);

        a.add(Util.text("\n", "white"));
        a.add(click("[Ranks] ", "yellow", "/clown ranks", "Show all ranks"));
        a.add(click("[Kits] ", "light_purple", "/clown kits", "Which VexBot kits are ready"));
        a.add(click("[Quit mission]", "red", "/clown quit", "Leave the current mission"));
        Util.raw(s, p, a);
    }

    private static void section(JsonArray a, String head, String color, Cfg c, boolean big, int ri, Data.Rec rec) {
        a.add(bold(head, color));
        for (Cfg.Mission m : c.missions) {
            if (m.big != big) continue;
            String best = rec.best.get(m.id);
            if (ri >= m.minRank) {
                a.add(click("[Start] ", "green", "/clown start " + m.id, m.summary));
                a.add(Util.text(m.title, "white"));
                a.add(Util.text("  +" + m.reward + (best != null ? "  best " + best : ""), "gray"));
            } else {
                a.add(Util.text("[Locked] " + m.title + "  (" + Cfg.rankName(m.minRank) + ")", "dark_gray"));
            }
            a.add(Util.text("\n", "white"));
        }
    }

    static void ranks(ServerPlayer p) {
        Data.Rec rec = Data.rec(p.getUUID());
        int ri = Cfg.rankOf(rec.tokens);
        Util.say(p, "Ranks (you have " + rec.tokens + " tokens):");
        List<Cfg.Rank> rs = Cfg.get().ranks;
        for (int i = 0; i < rs.size(); i++) {
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    (i == ri ? "\u00a7e> " : "\u00a77  ") + rs.get(i).name + " - " + rs.get(i).tokens + " tokens"));
        }
    }

    static void kits(MinecraftServer s, ServerPlayer p) {
        String st = Bridge.status();
        if (st != null) { Util.say(p, st); return; }
        List<String> needed = new ArrayList<>();
        for (Cfg.Mission m : Cfg.get().missions)
            for (Cfg.Wave w : m.waves)
                for (Cfg.Enemy e : w.enemies)
                    if (!needed.contains(e.kit)) needed.add(e.kit);
        Util.say(p, "VexBot kits the missions use:");
        for (String k : needed) {
            boolean ok = Bridge.kitExists(s, k);
            p.sendSystemMessage(net.minecraft.network.chat.Component.literal((ok ? "\u00a7a  ready  " : "\u00a7c  MISSING  ") + k));
        }
    }
}
