package dev.clownfreeplay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/clownfreeplay.json - ranks and missions. Edit it freely (kit names, sites, rewards...). */
public final class Cfg {
    public static final class Rank {
        public String name = "Rank";
        public int tokens = 0;
        public Rank() {}
        Rank(String n, int t) { name = n; tokens = t; }
    }

    public static final class Enemy {
        public String kit = "clown_grunt";
        public int count = 1;
        public Enemy() {}
        Enemy(String k, int c) { kit = k; count = c; }
    }

    public static final class Wave {
        public String title = "";
        public List<Enemy> enemies = new ArrayList<>();
    }

    public static final class Mission {
        public String id = "";
        public String title = "";
        public String summary = "";
        /** A UnstableStory site name (e.g. CIV_MERCHANT) or PLAINS. */
        public String site = "PLAINS";
        public int minRank = 0;
        public int reward = 2;
        /** Seconds. */
        public int timeLimit = 300;
        public boolean big = false;
        /** Optional offset from the site's entry point. */
        public int dx = 0;
        public int dz = 0;
        public List<Wave> waves = new ArrayList<>();
    }

    public boolean allowDebug = true;
    public String note = "Sites: see config/unstablefarlands or the StorySite list. Use PLAINS for open ground. Kits are VexBot kits.";
    public List<Rank> ranks = new ArrayList<>();
    public List<Mission> missions = new ArrayList<>();

    private static Cfg INSTANCE;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static Cfg get() {
        if (INSTANCE == null) INSTANCE = defaults();
        return INSTANCE;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("clownfreeplay.json");
    }

    static void load() {
        Path p = file();
        try {
            if (Files.exists(p)) {
                INSTANCE = GSON.fromJson(Files.readString(p), Cfg.class);
            } else {
                INSTANCE = defaults();
                Files.writeString(p, GSON.toJson(INSTANCE));
            }
        } catch (Exception e) {
            Util.LOG.warn("Could not read clownfreeplay.json, using defaults", e);
            INSTANCE = defaults();
        }
        if (INSTANCE == null) INSTANCE = defaults();
        if (INSTANCE.ranks == null || INSTANCE.ranks.isEmpty()) INSTANCE.ranks = defaults().ranks;
        if (INSTANCE.missions == null) INSTANCE.missions = new ArrayList<>();
    }

    static Mission mission(String id) {
        for (Mission m : get().missions) if (m.id.equalsIgnoreCase(id)) return m;
        return null;
    }

    static List<String> missionIds() {
        List<String> l = new ArrayList<>();
        for (Mission m : get().missions) l.add(m.id);
        return l;
    }

    static int rankOf(int tokens) {
        int r = 0;
        List<Rank> rs = get().ranks;
        for (int i = 0; i < rs.size(); i++) if (tokens >= rs.get(i).tokens) r = i;
        return r;
    }

    static String rankName(int i) {
        List<Rank> rs = get().ranks;
        return rs.get(Math.max(0, Math.min(i, rs.size() - 1))).name;
    }

    // ---- defaults -------------------------------------------------------

    private static Wave w(String title, Object... kitCount) {
        Wave w = new Wave();
        w.title = title;
        for (int i = 0; i + 1 < kitCount.length; i += 2) w.enemies.add(new Enemy((String) kitCount[i], (Integer) kitCount[i + 1]));
        return w;
    }

    private static Mission m(String id, String title, String summary, String site, int minRank, int reward, int limit, boolean big, Wave... waves) {
        Mission m = new Mission();
        m.id = id; m.title = title; m.summary = summary; m.site = site;
        m.minRank = minRank; m.reward = reward; m.timeLimit = limit; m.big = big;
        for (Wave x : waves) m.waves.add(x);
        return m;
    }

    private static Cfg defaults() {
        Cfg c = new Cfg();
        c.ranks.add(new Rank("Squirt", 0));
        c.ranks.add(new Rank("Joker", 6));
        c.ranks.add(new Rank("Jester", 16));
        c.ranks.add(new Rank("Harlequin", 32));
        c.ranks.add(new Rank("Ringmaster", 60));

        String G = "clown_grunt", B = "clown_brute", A = "clown_archer", K = "clown_boss", X = "clown_king";

        c.missions.add(m("big_top_brawl", "Big Top Brawl", "Warm up on open ground.", "PLAINS", 0, 2, 240, false,
                w("Wave 1", G, 3), w("Wave 2", G, 4)));
        c.missions.add(m("merchant_heist", "Merchant City Heist", "Clown thieves are raiding the stalls.", "CIV_MERCHANT", 0, 3, 300, false,
                w("Wave 1", G, 4), w("Wave 2", G, 3, A, 2)));
        c.missions.add(m("cave_chaos", "Cave Kingdom Chaos", "Pranksters in the caves.", "CIV_CAVES", 1, 3, 300, false,
                w("Wave 1", G, 4, B, 1), w("Wave 2", B, 2, A, 2)));
        c.missions.add(m("steam_sideshow", "Steampunk Sideshow", "The circus came to Steampunk City.", "CIV_STEAMPUNK", 1, 4, 360, false,
                w("Wave 1", G, 5), w("Wave 2", B, 2, A, 3)));
        c.missions.add(m("redstone_prank", "Redstone Town Prank War", "Someone rigged every button.", "LAW_REDSTONE_TOWN", 2, 4, 360, false,
                w("Wave 1", G, 5, A, 2), w("Wave 2", B, 3, A, 3)));
        c.missions.add(m("smugglers_ambush", "Smuggler's Pass Ambush", "Take the pass back from the clowns.", "LAW_SMUGGLERS_PASS", 2, 5, 360, false,
                w("Wave 1", G, 4, A, 3), w("Wave 2", B, 4, A, 2)));
        c.missions.add(m("statue_showdown", "2v1000 Statue Showdown", "Fight at the statue.", "LAW_STATUE", 3, 5, 420, false,
                w("Wave 1", G, 6, A, 3), w("Wave 2", B, 4, K, 1)));
        c.missions.add(m("factory_funhouse", "Boosfer's Funhouse", "The factory is a funhouse now.", "LAW_BOOSFER_FACTORY", 3, 6, 420, false,
                w("Wave 1", G, 6, B, 2), w("Wave 2", B, 4, A, 4), w("Wave 3", K, 1, B, 3)));

        c.missions.add(m("arena_plains", "Grand Plains Arena", "Big battle on open plains.", "PLAINS", 1, 8, 600, true,
                w("Wave 1", G, 6), w("Wave 2", G, 4, A, 3), w("Wave 3", B, 4, G, 4), w("BOSS", K, 1, B, 3)));
        c.missions.add(m("pirate_city", "Battle of Pirate City", "The whole ring city is up for grabs.", "LAW_PIRATE_BASE", 2, 10, 900, true,
                w("Wave 1", G, 6), w("Wave 2", G, 4, A, 3), w("Wave 3", B, 4, G, 4), w("BOSS", K, 1, B, 4)));
        c.missions.add(m("orbital_circus", "Orbital Circus", "A battle under the orbital cannons.", "ORBITAL_DEFENSE", 3, 12, 900, true,
                w("Wave 1", G, 6, A, 2), w("Wave 2", B, 4, A, 4), w("Wave 3", B, 6, G, 4), w("BOSS", K, 2, B, 4)));
        c.missions.add(m("capital_siege", "Siege of the Capital", "Take the Capital City.", "CIV_CAPITOL", 3, 12, 900, true,
                w("Wave 1", G, 8), w("Wave 2", B, 4, A, 4), w("Wave 3", B, 6, G, 6), w("BOSS", K, 2, B, 6)));
        c.missions.add(m("null_carnival", "NULL Capital Carnival", "The final big battle.", "NULL_CAPITAL", 4, 16, 1200, true,
                w("Wave 1", G, 8, A, 4), w("Wave 2", B, 6, A, 4), w("Wave 3", B, 8, G, 6), w("Wave 4", K, 2, B, 6), w("FINAL BOSS", X, 1, K, 2, B, 4)));
        return c;
    }
}
