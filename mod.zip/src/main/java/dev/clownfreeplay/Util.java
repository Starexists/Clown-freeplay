package dev.clownfreeplay;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

final class Util {
    static final Logger LOG = LoggerFactory.getLogger("clownfreeplay");

    private Util() {}

    /** Runs a command as the server (suppressed output). */
    static void cmd(MinecraftServer s, String c) {
        try {
            s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withSuppressedOutput(), c);
        } catch (Throwable t) {
            LOG.warn("Command failed: {}", c, t);
        }
    }

    /** "minecraft:overworld" etc, read from ResourceKey's text form. */
    static String dim(Level l) {
        String t = String.valueOf(l.dimension());
        int i = t.lastIndexOf("/ ");
        int j = t.lastIndexOf(']');
        if (i >= 0 && j > i) return t.substring(i + 2, j).trim();
        return "minecraft:overworld";
    }

    static void say(ServerPlayer p, String msg) {
        p.sendSystemMessage(Component.literal("\u00a76[Clown] \u00a7f" + msg));
    }

    static String num(double d) {
        return String.format(Locale.ROOT, "%.2f", d);
    }

    static JsonObject text(String t, String color) {
        JsonObject o = new JsonObject();
        o.addProperty("text", t);
        o.addProperty("color", color);
        return o;
    }

    static void raw(MinecraftServer s, ServerPlayer p, JsonElement e) {
        cmd(s, "tellraw " + p.getScoreboardName() + " " + e);
    }

    static void title(MinecraftServer s, ServerPlayer p, String main, String sub, String color) {
        String n = p.getScoreboardName();
        cmd(s, "title " + n + " times 10 50 15");
        cmd(s, "title " + n + " subtitle " + text(sub, "white"));
        cmd(s, "title " + n + " title " + text(main, color));
    }
}
