# Clown Freeplay (UnstableStory add-on)

Needs: Minecraft 1.21.11 (Fabric), Fabric API, UnstableStory 1.0.17, VexBot, Unstable Generation.

In game: type /clown (or tap the menu). Tap [Start] on a mission.
  /clown ranks   /clown kits   /clown quit
  /clown debug tokens 50   (testing; turn off with allowDebug=false in the config)

## VexBot kits you need to make (names are editable in config/clownfreeplay.json)
  clown_grunt   - basic enemy
  clown_brute   - tougher enemy
  clown_archer  - ranged enemy
  clown_boss    - boss
  clown_king    - final boss (NULL Capital Carnival)

/clown kits shows which ones are still missing.

## Config
config/clownfreeplay.json is made on first launch. Edit missions, waves, kits, sites, rewards and ranks there.
"site" can be any UnstableStory site (CIV_MERCHANT, LAW_PIRATE_BASE, ORBITAL_DEFENSE, ...) or PLAINS.
If a site isn't in your world, the mission falls back to open plains.
Progress is saved in config/clownfreeplay_data.json.
