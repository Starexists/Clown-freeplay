package dev.universefreeplay;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Runs missions: teleport, spawn waves of VexBot enemies, track kills, rank players up. */
final class Manager {
    private static final int PREP = 0, WAVE = 1, BREAK = 2, END = 3;

    private static final Map<UUID, Run> RUNS = new HashMap<>();
    private static final Random RNG = new Random();

    private static final class Bot {
        final String name;
        final int at;
        boolean seen, dead;
        Bot(String name, int at) { this.name = name; this.at = at; }
    }

    private static final class Run {
        Cfg.Mission m;
        UUID id;
        String pname, origDim, arenaDim = "minecraft:overworld", bar;
        double ox, oy, oz, ax, ay, az;
        int state = PREP, wave = -1, until, startTick, waveTotal, waveKills, waveFail;
        List<Bot> bots = new ArrayList<>();
        String grade = "B";
        List<String> grunts = new ArrayList<>(), elites = new ArrayList<>();
        List<Cfg.Character> chars = new ArrayList<>();
        Cfg.Character boss;
    }

    private Manager() {}

    static boolean busy(UUID id) { return RUNS.containsKey(id); }

    // ---- start / quit ---------------------------------------------------

    static void start(MinecraftServer s, ServerPlayer p, String missionId) {
        Cfg.Mission m = Cfg.mission(missionId);
        if (m == null) { Util.say(p, "Unknown mission: " + missionId); return; }
        if (m.waves == null || m.waves.isEmpty()) { Util.say(p, "That mission has no waves in the config."); return; }
        if (RUNS.containsKey(p.getUUID())) { Util.say(p, "You're already in a mission. Use /universe quit to leave it."); return; }

        Data.Rec rec = Data.rec(p.getUUID());
        rec.name = p.getScoreboardName();
        if (m.tier > rec.rank) { Util.say(p, "Locked - reach rank " + Cfg.rankName(m.tier) + " first."); return; }

        String st = Bridge.status();
        if (st != null) { Util.say(p, st); return; }

        Cfg.Empire emp = Cfg.empire(m);
        List<String> grunts = new ArrayList<>(), elites = new ArrayList<>(), missing = new ArrayList<>();
        List<Cfg.Character> chars = new ArrayList<>();
        Cfg.Character boss = null;
        for (String k : emp.kits) if (Bridge.kitExists(s, k)) grunts.add(k); else missing.add(k);
        for (String k : emp.elite) if (Bridge.kitExists(s, k)) elites.add(k); else missing.add(k);
        if (Cfg.get().useCharacters) {
            for (Cfg.Character ch : emp.characters) if (Bridge.kitExists(s, ch.kit)) chars.add(ch); else missing.add(ch.kit);
            if (emp.boss != null) {
                if (Bridge.kitExists(s, emp.boss.kit)) boss = emp.boss; else missing.add(emp.boss.kit);
            }
        }
        if (grunts.isEmpty()) {
            Util.say(p, "None of the " + Cfg.empireId(m) + " kits exist in VexBot, so there is nobody to fight.");
            Util.say(p, "Missing: " + String.join(", ", missing.subList(0, Math.min(6, missing.size()))));
            Util.say(p, "Copy your kit folder into VexBot, or change the empire in config/universefreeplay.json.");
            return;
        }

        if (Cfg.get().giveRankKit) {
            String pk = Cfg.rankKit(m.tier);
            if (pk != null && !pk.isEmpty()) {
                if (Bridge.giveKit(s, p, pk)) Util.say(p, "You received the \u00a7e" + pk + "\u00a7f kit.");
                else Util.say(p, "Couldn't give you the '" + pk + "' kit. Make a VexBot kit with that name.");
            }
        }

        Run r = new Run();
        r.m = m;
        r.id = p.getUUID();
        r.pname = p.getScoreboardName();
        r.origDim = Util.dim(p.level());
        r.ox = p.getX(); r.oy = p.getY(); r.oz = p.getZ();
        r.bar = "universefreeplay:" + r.id.toString().replace("-", "");
        r.grunts = grunts; r.elites = elites; r.chars = chars; r.boss = boss;

        Bridge.Spot spot = null;
        if (!"PLAINS".equalsIgnoreCase(m.site)) {
            spot = Bridge.siteSpot(p, m.site, m.dx, m.dz);
            if (spot == null) Util.say(p, "That build isn't available in this world - using open plains instead.");
        }
        if (spot != null) {
            Util.cmd(s, "execute in " + spot.dim() + " run tp " + r.pname + " " + Util.num(spot.x()) + " " + Util.num(spot.y()) + " " + Util.num(spot.z()));
        } else {
            Util.cmd(s, "execute as " + r.pname + " in minecraft:overworld run spreadplayers 0 0 100 3000 false " + r.pname);
        }

        int now = s.getTickCount();
        r.until = now + 60;
        r.startTick = now;
        RUNS.put(r.id, r);

        Util.cmd(s, "bossbar remove " + r.bar);
        Util.cmd(s, "bossbar add " + r.bar + " " + Util.text(m.title, "white"));
        Util.cmd(s, "bossbar set " + r.bar + " players " + r.pname);
        Util.cmd(s, "bossbar set " + r.bar + " color red");
        Util.title(s, p, m.title, m.big ? "BIG BATTLE" : "Mission start", m.big ? "red" : "gold");
        Util.say(p, "Mission: " + m.title + " - get ready!");
    }

    static void quit(MinecraftServer s, ServerPlayer p) {
        Run r = RUNS.get(p.getUUID());
        if (r == null) { Util.say(p, "You're not in a mission."); return; }
        end(s, r, p, "You left the mission.");
    }

    static void shutdown(MinecraftServer s) {
        for (Run r : new ArrayList<>(RUNS.values())) {
            cleanup(s, r);
        }
        RUNS.clear();
    }

    // ---- ticking --------------------------------------------------------

    static void tick(MinecraftServer s) {
        int now = s.getTickCount();
        if (now % 10 != 0 || RUNS.isEmpty()) return;
        for (Run r : new ArrayList<>(RUNS.values())) {
            try {
                step(s, r, now);
            } catch (Throwable t) {
                Util.LOG.warn("Mission error", t);
                ServerPlayer p = s.getPlayerList().getPlayer(r.id);
                end(s, r, p, "Something went wrong - mission cancelled.");
            }
        }
    }

    private static void step(MinecraftServer s, Run r, int now) {
        ServerPlayer p = s.getPlayerList().getPlayer(r.id);
        if (p == null || !p.isAlive()) {
            end(s, r, p, "You were knocked out - mission failed.");
            return;
        }
        switch (r.state) {
            case PREP -> {
                if (now >= r.until) {
                    r.ax = p.getX(); r.ay = p.getY(); r.az = p.getZ();
                    r.arenaDim = Util.dim(p.level());
                    r.startTick = now;
                    startWave(s, p, r, now, 0);
                }
            }
            case WAVE -> stepWave(s, p, r, now);
            case BREAK -> {
                if (now >= r.until) startWave(s, p, r, now, r.wave + 1);
                else updateBar(s, r, "Next wave soon...", 0, Math.max(1, r.waveTotal), now);
            }
            case END -> {
                if (now >= r.until) {
                    home(s, r, p);
                    cleanup(s, r);
                    RUNS.remove(r.id);
                }
            }
            default -> { }
        }
    }

    private static void startWave(MinecraftServer s, ServerPlayer p, Run r, int now, int idx) {
        Cfg.Wave w = r.m.waves.get(idx);
        r.wave = idx;
        r.state = WAVE;
        r.bots.clear();
        r.waveKills = 0;
        r.waveFail = 0;

        int total = Math.max(1, Math.min(w.count, 20));
        r.waveTotal = total;
        Level level = p.level();

        // Plan the wave: boss first, then some named main characters, the rest random soldiers.
        List<Cfg.Character> named = new ArrayList<>();
        if (w.boss && r.boss != null) named.add(r.boss);
        List<Cfg.Character> pool = new ArrayList<>(r.chars);
        java.util.Collections.shuffle(pool, RNG);
        int extra = idx == 0 ? 0 : 1 + idx / 2;
        for (Cfg.Character ch : pool) {
            if (named.size() >= total || extra-- <= 0) break;
            if (!ch.name.equalsIgnoreCase(r.boss == null ? "" : r.boss.name)) named.add(ch);
        }

        for (int i = 0; i < total; i++) {
            String name = null, kit;
            if (i < named.size() && s.getPlayerList().getPlayerByName(named.get(i).name) == null) {
                name = named.get(i).name;
                kit = named.get(i).kit;
            } else {
                boolean elite = idx > 0 && !r.elites.isEmpty() && RNG.nextInt(100) < 35;
                kit = elite ? pick(r.elites) : pick(r.grunts);
            }
            if (name == null) name = randomName(s);

            double[] g = ground(level, r.ax, r.ay, r.az);
            double x = g != null ? g[0] : r.ax + (RNG.nextDouble() * 2 - 1) * 2;
            double y = g != null ? g[1] : r.ay;
            double z = g != null ? g[2] : r.az + (RNG.nextDouble() * 2 - 1) * 2;
            float yaw = (float) Math.toDegrees(Math.atan2(-(r.ax - x), r.az - z));

            if (Bridge.spawn(s, name, x, y, z, yaw, r.arenaDim, kit)) {
                r.bots.add(new Bot(name, now));
                if (Cfg.get().dressBots) Bridge.dress(s, name, name);
            } else {
                r.waveFail++;
            }
        }

        String label = w.title == null || w.title.isEmpty() ? "Wave " + (idx + 1) : w.title;
        boolean boss = (label.toUpperCase().contains("BOSS") || label.toUpperCase().contains("FINAL"));
        Util.title(s, p, label, total + " enemies", boss ? "dark_red" : "gold");
        Util.cmd(s, "playsound minecraft:entity.evoker.prepare_summon master " + r.pname);
        if (r.bots.isEmpty()) {
            end(s, r, p, "No enemies could spawn. Check your VexBot kits and the server log.");
        }
    }

    /** A random real Minecraft name that isn't online right now (the skin is fetched by this name). */
    private static String randomName(MinecraftServer s) {
        List<String> names = Cfg.get().randomNames;
        for (int i = 0; i < 40 && !names.isEmpty(); i++) {
            String n = names.get(RNG.nextInt(names.size()));
            if (n.length() >= 3 && n.length() <= 16 && s.getPlayerList().getPlayerByName(n) == null) return n;
        }
        String base = "Clown";
        for (int i = 0; i < 200; i++) {
            String n = base + RNG.nextInt(100000);
            if (s.getPlayerList().getPlayerByName(n) == null) return n;
        }
        return base + System.nanoTime() % 100000;
    }

    private static String pick(List<String> l) {
        return l.get(RNG.nextInt(l.size()));
    }

    /** A dry, open spot on solid ground near (cx,cy,cz), or null. Keeps bots out of walls and water. */
    private static double[] ground(Level level, double cx, double cy, double cz) {
        for (int attempt = 0; attempt < 24; attempt++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double rad = 4 + RNG.nextDouble() * (attempt < 12 ? 6 : 10);
            int x = (int) Math.floor(cx + Math.cos(ang) * rad);
            int z = (int) Math.floor(cz + Math.sin(ang) * rad);
            for (int yy = (int) Math.floor(cy) + 3; yy >= (int) Math.floor(cy) - 6; yy--) {
                if (solidDry(level, new BlockPos(x, yy - 1, z)) && free(level, new BlockPos(x, yy, z)) && free(level, new BlockPos(x, yy + 1, z))) {
                    return new double[]{x + 0.5, yy, z + 0.5};
                }
            }
        }
        return null;
    }

    private static boolean free(Level level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        return !st.blocksMotion() && st.getFluidState().isEmpty();
    }

    private static boolean solidDry(Level level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        return st.blocksMotion() && st.getFluidState().isEmpty();
    }

    private static void stepWave(MinecraftServer s, ServerPlayer p, Run r, int now) {
        int alive = 0;
        for (Bot b : r.bots) {
            if (b.dead) continue;
            ServerPlayer bp = Bridge.bot(s, b.name);
            boolean up = bp != null && bp.isAlive();
            if (up) {
                b.seen = true;
                alive++;
            } else if (b.seen) {
                b.dead = true;
                r.waveKills++;
                Bridge.despawn(s, b.name);
            } else if (now - b.at > 200) {
                b.dead = true;
                r.waveFail++;
            } else {
                alive++;
            }
        }

        if (now - r.startTick > r.m.timeLimit * 20) {
            end(s, r, p, "Time's up - mission failed.");
            return;
        }
        if (alive == 0 && r.waveKills == 0 && r.waveFail > 0) {
            end(s, r, p, "The enemies failed to spawn. Check your VexBot kits and the server log.");
            return;
        }

        if (alive > 0 && now % 60 == 0) {
            for (Bot b : r.bots) if (!b.dead && b.seen) Bridge.hunt(b.name, r.pname);
        }

        Cfg.Wave w = r.m.waves.get(r.wave);
        String label = w.title == null || w.title.isEmpty() ? "Wave " + (r.wave + 1) : w.title;
        int left = Math.max(0, r.m.timeLimit - (now - r.startTick) / 20);
        updateBar(s, r, label + "  -  " + alive + " left  -  " + (left / 60) + ":" + String.format("%02d", left % 60), alive, Math.max(1, r.waveTotal), now);

        if (alive == 0) {
            if (r.wave + 1 < r.m.waves.size()) {
                r.state = BREAK;
                r.until = now + 80;
                Util.title(s, p, "Wave cleared!", "Next wave incoming", "green");
            } else {
                win(s, p, r, now);
            }
        }
    }

    private static void updateBar(MinecraftServer s, Run r, String text, int value, int max, int now) {
        if (now % 20 != 0 && r.state == WAVE) return;
        Util.cmd(s, "bossbar set " + r.bar + " name " + Util.text(r.m.title + "  |  " + text, "white"));
        Util.cmd(s, "bossbar set " + r.bar + " max " + max);
        Util.cmd(s, "bossbar set " + r.bar + " value " + value);
    }

    // ---- finish ---------------------------------------------------------

    private static void win(MinecraftServer s, ServerPlayer p, Run r, int now) {
        Cfg.Mission m = r.m;
        double used = (now - r.startTick) / (double) Math.max(1, m.timeLimit * 20);
        r.grade = used < 0.5 ? "S" : used < 0.75 ? "A" : "B";

        Data.Rec rec = Data.rec(r.id);
        rec.name = r.pname;
        int before = rec.rank;
        rec.clears.put(m.id, rec.clears.getOrDefault(m.id, 0) + 1);
        String oldBest = rec.best.get(m.id);
        if (oldBest == null || order(r.grade) > order(oldBest)) rec.best.put(m.id, r.grade);

        int last = Cfg.lastTier();
        int done = Cfg.clearedInTier(rec, m.tier);
        int total = Cfg.countInTier(m.tier);
        if (m.tier == rec.rank && rec.rank < last && done >= total) rec.rank++;
        Data.save();

        Util.title(s, p, "MISSION COMPLETE", "Grade " + r.grade, "green");
        Util.cmd(s, "playsound minecraft:ui.toast.challenge_complete master " + r.pname);
        if (m.tier == last) {
            Util.say(p, m.title + " cleared! Grade " + r.grade + ". Universe clears: " + Data.universeClears(rec));
        } else if (m.tier == before && rec.rank == before) {
            Util.say(p, m.title + " cleared! Grade " + r.grade + ". " + Cfg.rankName(m.tier) + " missions: " + done + "/" + total);
        } else if (m.tier < before) {
            Util.say(p, m.title + " cleared (practice). Grade " + r.grade + ".");
        }
        if (rec.rank > before) {
            Util.say(p, "\u00a7eRANK UP! You are now a " + Cfg.rankName(rec.rank) + "!");
            Util.cmd(s, "title " + r.pname + " actionbar " + Util.text("RANK UP: " + Cfg.rankName(rec.rank), "gold"));
            Util.cmd(s, "tellraw @a " + Util.text(r.pname + " ranked up to " + Cfg.rankName(rec.rank) + " in Universe Freeplay!", "gold"));
        }
        Util.cmd(s, "bossbar set " + r.bar + " name " + Util.text("Mission complete - returning...", "green"));
        r.state = END;
        r.until = now + 100;
    }

    static int order(String g) {
        return "S".equals(g) ? 3 : "A".equals(g) ? 2 : "B".equals(g) ? 1 : 0;
    }

    /** Failure / quit: no reward. */
    private static void end(MinecraftServer s, Run r, ServerPlayer p, String why) {
        if (p != null) Util.say(p, why);
        home(s, r, p);
        cleanup(s, r);
        RUNS.remove(r.id);
    }

    private static void home(MinecraftServer s, Run r, ServerPlayer p) {
        if (p != null && p.isAlive()) {
            Util.cmd(s, "execute in " + r.origDim + " run tp " + r.pname + " " + Util.num(r.ox) + " " + Util.num(r.oy) + " " + Util.num(r.oz));
        }
    }

    private static void cleanup(MinecraftServer s, Run r) {
        for (Bot b : r.bots) Bridge.despawn(s, b.name);
        r.bots.clear();
        Util.cmd(s, "bossbar remove " + r.bar);
    }
}
