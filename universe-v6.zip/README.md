# Universe Freeplay (UnstableStory add-on)

Needs: Minecraft 1.21.11 (Fabric), Fabric API, UnstableStory 1.0.17, VexBot, Unstable Generation.

Journal (scrolls with the mouse wheel / touch): /universe, the Quick Actions key (see Controls), or the pause-menu button.
Commands: /universe  /universe tier <n>  /universe ranks  /universe info  /universe top  /universe kits  /universe quit
Testing: /universe debug rank <0-4>   (turn off with allowDebug=false in the config)

Ranks: Human -> Planet -> Star -> Galaxy -> Universe (leader).
Clear all 5 missions of your rank once to move up. Universe is the leader tier: big battles, repeatable, /universe top.

## Bots, names, skins and kits
* Regular soldiers get a RANDOM real Minecraft name from "randomNames" in config/universefreeplay.json (paste names from NameMC there).
  The skin is fetched by that name, and they use their EMPIRE's kits (mafia, law, null, civ, bandit, pirates, ...).
* MAIN CHARACTERS (an empire's boss and named elites) use their own name, skin and kit, e.g. Ashswag, SargeLAW, Prince.
  Edit empires[].boss / empires[].characters ("name" = Minecraft name, "kit" = VexBot kit). Set useCharacters=false to turn them off.
* YOU get a rank kit when a mission starts: human, planet, star, galaxy, universe (ranks[].kit in the config).
  Make these 5 kits, or point ranks[].kit at kits you already have. Your inventory is replaced by the kit.
* /universe kits shows which kits are ready or missing.

The config is regenerated automatically when its version changes (the old one is kept as universefreeplay.json.old).
