package dev.universefreeplay;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public final class UniverseFreeplay implements ModInitializer {
    @Override
    public void onInitialize() {
        Cfg.load();
        Data.load();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> Cmds.register(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(Manager::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(Manager::shutdown);
        Util.LOG.info("Universe Freeplay loaded: {} missions, {} ranks", Cfg.get().missions.size(), Cfg.get().ranks.size());
    }
}
