package dev.universefreeplay;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Talks to UnstableStory / VexBot through reflection, so this add-on never needs
 * UnstableStory's classes at compile time.
 */
final class Bridge {
    record Spot(double x, double y, double z, String dim) {}

    private static Class<?> vb, sd, site, atSite;
    private static String problem;
    private static boolean tried;

    private Bridge() {}

    /** null when everything needed is present, otherwise a message for the player. */
    static synchronized String status() {
        if (!tried) {
            tried = true;
            try {
                vb = Class.forName("dev.unstablefarlands.integration.VexBotBridge");
                sd = Class.forName("dev.unstablefarlands.story.StoryDirector");
                site = Class.forName("dev.unstablefarlands.world.StorySite");
                atSite = Class.forName("dev.unstablefarlands.story.script.Script$AtSite");
            } catch (Throwable t) {
                problem = "UnstableStory is not loaded.";
            }
        }
        if (problem != null) return problem;
        try {
            if (!Boolean.TRUE.equals(call(vb, "available"))) return "VexBot is not loaded.";
        } catch (Throwable t) {
            return "Could not talk to UnstableStory/VexBot: " + t;
        }
        return null;
    }

    private static Method find(Class<?> c, String name, int argc) {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == argc && Modifier.isStatic(m.getModifiers())) return m;
        }
        throw new NoSuchMethodError(c.getSimpleName() + "." + name + "/" + argc);
    }

    private static Object call(Class<?> c, String name, Object... args) throws Exception {
        try {
            return find(c, name, args.length).invoke(null, args);
        } catch (InvocationTargetException e) {
            Throwable t = e.getCause() == null ? e : e.getCause();
            if (t instanceof Exception ex) throw ex;
            throw new RuntimeException(t);
        }
    }

    static boolean kitExists(MinecraftServer s, String kit) {
        try {
            return Boolean.TRUE.equals(call(vb, "kitExists", s, kit));
        } catch (Throwable t) {
            Util.LOG.warn("kitExists failed", t);
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    static List<String> kits(MinecraftServer s) {
        try {
            Object o = call(vb, "kits", s);
            if (o instanceof List<?> l) return new ArrayList<>((List<String>) l);
        } catch (Throwable t) {
            Util.LOG.warn("kits failed", t);
        }
        return new ArrayList<>();
    }

    static boolean spawn(MinecraftServer s, String name, double x, double y, double z, float yaw, String dim, String kit) {
        try {
            return Boolean.TRUE.equals(call(vb, "spawn", s, name, new Vec3(x, y, z), yaw, dim, kit));
        } catch (Throwable t) {
            Util.LOG.warn("spawn failed for {}", name, t);
            return false;
        }
    }

    static void hunt(String bot, String target) {
        try { call(vb, "hunt", bot, target); } catch (Throwable ignored) {}
        try { call(vb, "attack", bot, target); } catch (Throwable ignored) {}
    }

    static void despawn(MinecraftServer s, String bot) {
        try { call(vb, "despawn", s, bot); } catch (Throwable ignored) {}
    }

    static ServerPlayer bot(MinecraftServer s, String name) {
        try {
            Object o = call(vb, "bot", s, name);
            return o instanceof ServerPlayer p ? p : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Where to stand for one of UnstableStory's builds: the site's own entry point (+ optional offset). */
    static Spot siteSpot(ServerPlayer p, String siteName, int dx, int dz) {
        try {
            Object st = site.getMethod("valueOf", String.class).invoke(null, siteName.toUpperCase(Locale.ROOT));
            int ex = site.getField("entryX").getInt(st) + dx;
            int ez = site.getField("entryZ").getInt(st) + dz;
            int ey = site.getField("entryY").getInt(st);
            Object target;
            try {
                target = atSite.getConstructor(site, int.class, int.class, int.class).newInstance(st, ex, ez, ey);
            } catch (NoSuchMethodException e) {
                target = atSite.getConstructor(site, int.class, int.class).newInstance(st, ex, ez);
            }
            Object v = null;
            try { v = call(sd, "resolve", p, target, Boolean.TRUE); } catch (Throwable ignored) {}
            if (!(v instanceof Vec3)) v = call(sd, "resolveQuiet", p, target);
            if (!(v instanceof Vec3 vec)) return null;
            String dim = "minecraft:overworld";
            try {
                Object lvl = call(sd, "levelFor", p, target);
                if (lvl instanceof Level l) dim = Util.dim(l);
            } catch (Throwable ignored) {}
            return new Spot(vec.x, vec.y, vec.z, dim);
        } catch (Throwable t) {
            Util.LOG.warn("Could not resolve site {}", siteName, t);
            return null;
        }
    }

    static boolean giveKit(MinecraftServer s, ServerPlayer p, String kit) {
        try {
            return Boolean.TRUE.equals(call(vb, "giveKit", s, p, kit));
        } catch (Throwable t) {
            Util.LOG.warn("giveKit failed for {}", kit, t);
            return false;
        }
    }

    /** Dress a bot in a real player's skin (UnstableStory fetches it from Mojang). */
    static void dress(MinecraftServer s, String bot, String skinName) {
        try {
            Class<?> sk = Class.forName("dev.unstablefarlands.integration.VexBotSkins");
            call(sk, "dress", s, bot, skinName);
        } catch (Throwable t) {
            Util.LOG.warn("Could not dress {} as {}", bot, skinName, t);
        }
    }
}
