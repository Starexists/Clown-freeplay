package dev.universefreeplay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;

/** Per-player progress, saved to config/universefreeplay_data.json. */
public final class Data {
    public static final class Rec {
        public String name = "";
        public int rank = 0;
        public Map<String, Integer> clears = new HashMap<>();
        public Map<String, String> best = new HashMap<>();
    }

    public Map<String, Rec> players = new HashMap<>();

    private static Data I = new Data();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("universefreeplay_data.json");
    }

    static void load() {
        try {
            Path p = file();
            if (Files.exists(p)) {
                Data d = GSON.fromJson(Files.readString(p), Data.class);
                if (d != null && d.players != null) I = d;
            }
        } catch (Exception e) {
            Util.LOG.warn("Could not read universefreeplay_data.json", e);
        }
    }

    static void save() {
        try {
            Files.writeString(file(), GSON.toJson(I));
        } catch (Exception e) {
            Util.LOG.warn("Could not save universefreeplay_data.json", e);
        }
    }

    static Rec rec(UUID id) {
        Rec r = I.players.computeIfAbsent(id.toString(), k -> new Rec());
        if (r.clears == null) r.clears = new HashMap<>();
        if (r.best == null) r.best = new HashMap<>();
        if (r.name == null) r.name = "";
        return r;
    }

    static List<Rec> all() {
        return new ArrayList<>(I.players.values());
    }

    /** Total clears of leader-tier (Universe) missions. */
    static int universeClears(Rec r) {
        int n = 0;
        for (Cfg.Mission m : Cfg.get().missions) if (m.tier == Cfg.lastTier()) n += r.clears.getOrDefault(m.id, 0);
        return n;
    }
}
