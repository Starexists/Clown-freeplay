package dev.universefreeplay;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.level.ServerPlayer;

final class Cmds {
    private Cmds() {}

    private static int menu(CommandSourceStack src, int tier) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        Dialogs.main(src.getServer(), p, tier);
        return 1;
    }

    static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("universe")
                .executes(c -> menu(c.getSource(), Integer.MAX_VALUE))
                .then(Commands.literal("menu").executes(c -> menu(c.getSource(), Integer.MAX_VALUE)))
                .then(Commands.literal("tier")
                        .then(Commands.argument("n", IntegerArgumentType.integer(0, 20))
                                .executes(c -> menu(c.getSource(), IntegerArgumentType.getInteger(c, "n")))))
                .then(Commands.literal("start")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Cfg.missionIds(), b))
                                .executes(c -> {
                                    ServerPlayer p = c.getSource().getPlayerOrException();
                                    Manager.start(c.getSource().getServer(), p, StringArgumentType.getString(c, "id"));
                                    return 1;
                                })))
                .then(Commands.literal("quit").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Manager.quit(c.getSource().getServer(), p);
                    return 1;
                }))
                .then(Commands.literal("ranks").executes(c -> {
                    Dialogs.ranks(c.getSource().getServer(), c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("top").executes(c -> {
                    Dialogs.top(c.getSource().getServer(), c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("info").executes(c -> {
                    Dialogs.info(c.getSource().getServer(), c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("kits").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Dialogs.kits(c.getSource().getServer(), p);
                    return 1;
                }))
                .then(Commands.literal("debug")
                        .then(Commands.literal("rank")
                                .then(Commands.argument("n", IntegerArgumentType.integer(0, 20))
                                        .executes(c -> {
                                            ServerPlayer p = c.getSource().getPlayerOrException();
                                            if (!Cfg.get().allowDebug) {
                                                Util.say(p, "Debug commands are off (allowDebug in the config).");
                                                return 0;
                                            }
                                            Data.Rec r = Data.rec(p.getUUID());
                                            r.rank = Math.min(IntegerArgumentType.getInteger(c, "n"), Cfg.lastTier());
                                            Data.save();
                                            Util.say(p, "Rank set to " + Cfg.rankName(r.rank));
                                            return 1;
                                        })))));
    }
}
