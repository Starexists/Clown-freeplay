package dev.universefreeplay;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Clickable chat menu. Tap the green buttons. */
final class Menu {
    private Menu() {}

    private static JsonObject click(String text, String color, String command, String hover) {
        JsonObject o = Util.text(text, color);
        JsonObject ce = new JsonObject();
        ce.addProperty("action", "run_command");
        ce.addProperty("command", command);
        o.add("click_event", ce);
        if (hover != null) {
            JsonObject he = new JsonObject();
            he.addProperty("action", "show_text");
            he.addProperty("value", hover);
            o.add("hover_event", he);
        }
        return o;
    }

    private static JsonObject bold(String t, String color) {
        JsonObject o = Util.text(t, color);
        o.addProperty("bold", true);
        return o;
    }

    /** Shows the menu for one rank tier (the player's own rank by default). */
    static void open(MinecraftServer s, ServerPlayer p, int tier) {
        Cfg c = Cfg.get();
        Data.Rec rec = Data.rec(p.getUUID());
        rec.name = p.getScoreboardName();
        int last = Cfg.lastTier();
        tier = Math.max(0, Math.min(tier, Math.min(rec.rank, last)));

        JsonArray a = new JsonArray();
        a.add(new JsonPrimitive(""));
        a.add(bold("=== UNIVERSE FREEPLAY ===\n", "light_purple"));
        a.add(Util.text("Your rank: ", "gray"));
        a.add(bold(Cfg.rankName(rec.rank), "yellow"));
        a.add(Util.text("\n", "white"));

        int total = Cfg.countInTier(tier);
        int done = Cfg.clearedInTier(rec, tier);
        if (tier == rec.rank && rec.rank < last) {
            a.add(Util.text("Clear all " + total + " " + Cfg.rankName(tier) + " missions to become "
                    + Cfg.rankName(tier + 1) + "  (" + done + "/" + total + ")\n", "aqua"));
        } else if (tier == last) {
            a.add(Util.text("Leader tier: big battles. Your clears: " + Data.universeClears(rec) + "  (see /universe top)\n", "red"));
        } else {
            a.add(Util.text(Cfg.rankName(tier) + " missions (practice, no rank progress)\n", "dark_gray"));
        }

        a.add(bold("\n" + Cfg.rankName(tier) + " missions\n", "gold"));
        for (Cfg.Mission m : c.missions) {
            if (m.tier != tier) continue;
            boolean cleared = rec.clears.getOrDefault(m.id, 0) > 0;
            String best = rec.best.get(m.id);
            a.add(Util.text(cleared ? "[x] " : "[ ] ", cleared ? "green" : "gray"));
            a.add(click("[Start] ", "green", "/universe start " + m.id, m.summary));
            a.add(Util.text(m.title, "white"));
            if (best != null) a.add(Util.text("  best " + best, "gray"));
            a.add(Util.text("\n", "white"));
        }

        a.add(Util.text("\nRanks: ", "gray"));
        for (int t = 0; t <= Math.min(rec.rank, last); t++) {
            a.add(click("[" + Cfg.rankName(t) + "] ", t == tier ? "yellow" : "white", "/universe tier " + t, "Show " + Cfg.rankName(t) + " missions"));
        }
        a.add(Util.text("\n", "white"));
        a.add(click("[Kits] ", "light_purple", "/universe kits", "Which VexBot kits are ready"));
        a.add(click("[Top] ", "gold", "/universe top", "Universe leaderboard"));
        a.add(click("[Quit mission]", "red", "/universe quit", "Leave the current mission"));
        Util.raw(s, p, a);
    }

    static void ranks(ServerPlayer p) {
        Data.Rec rec = Data.rec(p.getUUID());
        Util.say(p, "Ranks (clear every mission of a rank to move up):");
        List<Cfg.Rank> rs = Cfg.get().ranks;
        for (int i = 0; i < rs.size(); i++) {
            String prog = i < Cfg.lastTier() ? Cfg.clearedInTier(rec, i) + "/" + Cfg.countInTier(i) : Data.universeClears(rec) + " clears";
            p.sendSystemMessage(Component.literal((i == rec.rank ? "\u00a7e> " : "\u00a77  ") + rs.get(i).name + " - " + prog));
        }
    }

    static void top(ServerPlayer p) {
        List<Data.Rec> l = new ArrayList<>();
        for (Data.Rec r : Data.all()) if (r.rank > 0 || Data.universeClears(r) > 0) l.add(r);
        l.sort(Comparator.<Data.Rec>comparingInt(r -> r.rank).reversed().thenComparing(Comparator.<Data.Rec>comparingInt(Data::universeClears).reversed()));
        Util.say(p, "Leaderboard (rank, then Universe clears):");
        int n = 0;
        for (Data.Rec r : l) {
            if (++n > 10) break;
            p.sendSystemMessage(Component.literal("\u00a77" + n + ". \u00a7f" + (r.name.isEmpty() ? "?" : r.name) + " \u00a77- " + Cfg.rankName(r.rank) + ", " + Data.universeClears(r) + " clears"));
        }
        if (l.isEmpty()) Util.say(p, "Nobody has ranked up yet.");
    }

    static void kits(MinecraftServer s, ServerPlayer p) {
        String st = Bridge.status();
        if (st != null) { Util.say(p, st); return; }
        List<String> needed = new ArrayList<>();
        for (Cfg.Mission m : Cfg.get().missions)
            for (Cfg.Wave w : m.waves)
                for (Cfg.Enemy e : w.enemies)
                    if (!needed.contains(e.kit)) needed.add(e.kit);
        Util.say(p, "VexBot kits the missions use:");
        for (String k : needed) {
            boolean ok = Bridge.kitExists(s, k);
            p.sendSystemMessage(Component.literal((ok ? "\u00a7a  ready  " : "\u00a7c  MISSING  ") + k));
        }
    }
}
