package dev.universefreeplay;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Runs missions: teleport, spawn waves of VexBot enemies, track kills, rank players up. */
final class Manager {
    private static final int PREP = 0, WAVE = 1, BREAK = 2, END = 3;

    private static final Map<UUID, Run> RUNS = new HashMap<>();
    private static final Random RNG = new Random();
    private static int counter = 0;

    private static final class Bot {
        final String name;
        final int at;
        boolean seen, dead;
        Bot(String name, int at) { this.name = name; this.at = at; }
    }

    private static final class Run {
        Cfg.Mission m;
        UUID id;
        String pname, origDim, arenaDim = "minecraft:overworld", bar;
        double ox, oy, oz, ax, ay, az;
        int state = PREP, wave = -1, until, startTick, waveTotal, waveKills, waveFail;
        List<Bot> bots = new ArrayList<>();
        String grade = "B";
    }

    private Manager() {}

    static boolean busy(UUID id) { return RUNS.containsKey(id); }

    // ---- start / quit ---------------------------------------------------

    static void start(MinecraftServer s, ServerPlayer p, String missionId) {
        Cfg.Mission m = Cfg.mission(missionId);
        if (m == null) { Util.say(p, "Unknown mission: " + missionId); return; }
        if (m.waves == null || m.waves.isEmpty()) { Util.say(p, "That mission has no waves in the config."); return; }
        if (RUNS.containsKey(p.getUUID())) { Util.say(p, "You're already in a mission. Use /universe quit to leave it."); return; }

        Data.Rec rec = Data.rec(p.getUUID());
        rec.name = p.getScoreboardName();
        if (m.tier > rec.rank) { Util.say(p, "Locked - reach rank " + Cfg.rankName(m.tier) + " first."); return; }

        String st = Bridge.status();
        if (st != null) { Util.say(p, st); return; }

        List<String> missing = new ArrayList<>();
        for (Cfg.Wave w : m.waves)
            for (Cfg.Enemy e : w.enemies)
                if (!missing.contains(e.kit) && !Bridge.kitExists(s, e.kit)) missing.add(e.kit);
        if (!missing.isEmpty()) {
            Util.say(p, "Missing VexBot kits: " + String.join(", ", missing));
            Util.say(p, "Make them with VexBot, or rename them in config/universefreeplay.json.");
            return;
        }

        Run r = new Run();
        r.m = m;
        r.id = p.getUUID();
        r.pname = p.getScoreboardName();
        r.origDim = Util.dim(p.level());
        r.ox = p.getX(); r.oy = p.getY(); r.oz = p.getZ();
        r.bar = "universefreeplay:" + r.id.toString().replace("-", "");

        Bridge.Spot spot = null;
        if (!"PLAINS".equalsIgnoreCase(m.site)) {
            spot = Bridge.siteSpot(p, m.site, m.dx, m.dz);
            if (spot == null) Util.say(p, "That build isn't available in this world - using open plains instead.");
        }
        if (spot != null) {
            Util.cmd(s, "execute in " + spot.dim() + " run tp " + r.pname + " " + Util.num(spot.x()) + " " + Util.num(spot.y()) + " " + Util.num(spot.z()));
        } else {
            Util.cmd(s, "execute as " + r.pname + " in minecraft:overworld run spreadplayers 0 0 100 3000 false " + r.pname);
        }

        int now = s.getTickCount();
        r.until = now + 60;
        r.startTick = now;
        RUNS.put(r.id, r);

        Util.cmd(s, "bossbar remove " + r.bar);
        Util.cmd(s, "bossbar add " + r.bar + " " + Util.text(m.title, "white"));
        Util.cmd(s, "bossbar set " + r.bar + " players " + r.pname);
        Util.cmd(s, "bossbar set " + r.bar + " color red");
        Util.title(s, p, m.title, m.big ? "BIG BATTLE" : "Mission start", m.big ? "red" : "gold");
        Util.say(p, "Mission: " + m.title + " - get ready!");
    }

    static void quit(MinecraftServer s, ServerPlayer p) {
        Run r = RUNS.get(p.getUUID());
        if (r == null) { Util.say(p, "You're not in a mission."); return; }
        end(s, r, p, "You left the mission.");
    }

    static void shutdown(MinecraftServer s) {
        for (Run r : new ArrayList<>(RUNS.values())) {
            cleanup(s, r);
        }
        RUNS.clear();
    }

    // ---- ticking --------------------------------------------------------

    static void tick(MinecraftServer s) {
        int now = s.getTickCount();
        if (now % 10 != 0 || RUNS.isEmpty()) return;
        for (Run r : new ArrayList<>(RUNS.values())) {
            try {
                step(s, r, now);
            } catch (Throwable t) {
                Util.LOG.warn("Mission error", t);
                ServerPlayer p = s.getPlayerList().getPlayer(r.id);
                end(s, r, p, "Something went wrong - mission cancelled.");
            }
        }
    }

    private static void step(MinecraftServer s, Run r, int now) {
        ServerPlayer p = s.getPlayerList().getPlayer(r.id);
        if (p == null || !p.isAlive()) {
            end(s, r, p, "You were knocked out - mission failed.");
            return;
        }
        switch (r.state) {
            case PREP -> {
                if (now >= r.until) {
                    r.ax = p.getX(); r.ay = p.getY(); r.az = p.getZ();
                    r.arenaDim = Util.dim(p.level());
                    r.startTick = now;
                    startWave(s, p, r, now, 0);
                }
            }
            case WAVE -> stepWave(s, p, r, now);
            case BREAK -> {
                if (now >= r.until) startWave(s, p, r, now, r.wave + 1);
                else updateBar(s, r, "Next wave soon...", 0, Math.max(1, r.waveTotal), now);
            }
            case END -> {
                if (now >= r.until) {
                    home(s, r, p);
                    cleanup(s, r);
                    RUNS.remove(r.id);
                }
            }
            default -> { }
        }
    }

    private static void startWave(MinecraftServer s, ServerPlayer p, Run r, int now, int idx) {
        Cfg.Wave w = r.m.waves.get(idx);
        r.wave = idx;
        r.state = WAVE;
        r.bots.clear();
        r.waveKills = 0;
        r.waveFail = 0;

        int total = 0;
        for (Cfg.Enemy e : w.enemies) total += Math.max(0, Math.min(e.count, 20));
        r.waveTotal = total;

        int n = 0;
        for (Cfg.Enemy e : w.enemies) {
            int cnt = Math.max(0, Math.min(e.count, 20));
            for (int i = 0; i < cnt; i++, n++) {
                String name = "Uni" + Integer.toString(++counter, 36);
                double ang = RNG.nextDouble() * Math.PI * 2;
                double rad = 5 + RNG.nextDouble() * 5;
                double x = r.ax + Math.cos(ang) * rad;
                double z = r.az + Math.sin(ang) * rad;
                float yaw = (float) Math.toDegrees(Math.atan2(-(r.ax - x), r.az - z));
                Bridge.despawn(s, name);
                if (Bridge.spawn(s, name, x, r.ay + 0.2, z, yaw, r.arenaDim, e.kit)) {
                    r.bots.add(new Bot(name, now));
                } else {
                    r.waveFail++;
                }
            }
        }

        String label = w.title == null || w.title.isEmpty() ? "Wave " + (idx + 1) : w.title;
        boolean boss = label.toUpperCase().contains("BOSS");
        Util.title(s, p, label, total + " enemies", boss ? "dark_red" : "gold");
        Util.cmd(s, "playsound minecraft:entity.evoker.prepare_summon master " + r.pname);
        if (r.bots.isEmpty()) {
            end(s, r, p, "No enemies could spawn. Check your VexBot kits and the server log.");
        }
    }

    private static void stepWave(MinecraftServer s, ServerPlayer p, Run r, int now) {
        int alive = 0;
        for (Bot b : r.bots) {
            if (b.dead) continue;
            ServerPlayer bp = Bridge.bot(s, b.name);
            boolean up = bp != null && bp.isAlive();
            if (up) {
                b.seen = true;
                alive++;
            } else if (b.seen) {
                b.dead = true;
                r.waveKills++;
                Bridge.despawn(s, b.name);
            } else if (now - b.at > 200) {
                b.dead = true;
                r.waveFail++;
            } else {
                alive++;
            }
        }

        if (now - r.startTick > r.m.timeLimit * 20) {
            end(s, r, p, "Time's up - mission failed.");
            return;
        }
        if (alive == 0 && r.waveKills == 0 && r.waveFail > 0) {
            end(s, r, p, "The enemies failed to spawn. Check your VexBot kits and the server log.");
            return;
        }

        if (alive > 0 && now % 60 == 0) {
            for (Bot b : r.bots) if (!b.dead && b.seen) Bridge.hunt(b.name, r.pname);
        }

        Cfg.Wave w = r.m.waves.get(r.wave);
        String label = w.title == null || w.title.isEmpty() ? "Wave " + (r.wave + 1) : w.title;
        int left = Math.max(0, r.m.timeLimit - (now - r.startTick) / 20);
        updateBar(s, r, label + "  -  " + alive + " left  -  " + (left / 60) + ":" + String.format("%02d", left % 60), alive, Math.max(1, r.waveTotal), now);

        if (alive == 0) {
            if (r.wave + 1 < r.m.waves.size()) {
                r.state = BREAK;
                r.until = now + 80;
                Util.title(s, p, "Wave cleared!", "Next wave incoming", "green");
            } else {
                win(s, p, r, now);
            }
        }
    }

    private static void updateBar(MinecraftServer s, Run r, String text, int value, int max, int now) {
        if (now % 20 != 0 && r.state == WAVE) return;
        Util.cmd(s, "bossbar set " + r.bar + " name " + Util.text(r.m.title + "  |  " + text, "white"));
        Util.cmd(s, "bossbar set " + r.bar + " max " + max);
        Util.cmd(s, "bossbar set " + r.bar + " value " + value);
    }

    // ---- finish ---------------------------------------------------------

    private static void win(MinecraftServer s, ServerPlayer p, Run r, int now) {
        Cfg.Mission m = r.m;
        double used = (now - r.startTick) / (double) Math.max(1, m.timeLimit * 20);
        r.grade = used < 0.5 ? "S" : used < 0.75 ? "A" : "B";

        Data.Rec rec = Data.rec(r.id);
        rec.name = r.pname;
        int before = rec.rank;
        rec.clears.put(m.id, rec.clears.getOrDefault(m.id, 0) + 1);
        String oldBest = rec.best.get(m.id);
        if (oldBest == null || order(r.grade) > order(oldBest)) rec.best.put(m.id, r.grade);

        int last = Cfg.lastTier();
        int done = Cfg.clearedInTier(rec, m.tier);
        int total = Cfg.countInTier(m.tier);
        if (m.tier == rec.rank && rec.rank < last && done >= total) rec.rank++;
        Data.save();

        Util.title(s, p, "MISSION COMPLETE", "Grade " + r.grade, "green");
        Util.cmd(s, "playsound minecraft:ui.toast.challenge_complete master " + r.pname);
        if (m.tier == last) {
            Util.say(p, m.title + " cleared! Grade " + r.grade + ". Universe clears: " + Data.universeClears(rec));
        } else if (m.tier == before && rec.rank == before) {
            Util.say(p, m.title + " cleared! Grade " + r.grade + ". " + Cfg.rankName(m.tier) + " missions: " + done + "/" + total);
        } else if (m.tier < before) {
            Util.say(p, m.title + " cleared (practice). Grade " + r.grade + ".");
        }
        if (rec.rank > before) {
            Util.say(p, "\u00a7eRANK UP! You are now a " + Cfg.rankName(rec.rank) + "!");
            Util.cmd(s, "title " + r.pname + " actionbar " + Util.text("RANK UP: " + Cfg.rankName(rec.rank), "gold"));
            Util.cmd(s, "tellraw @a " + Util.text(r.pname + " ranked up to " + Cfg.rankName(rec.rank) + " in Universe Freeplay!", "gold"));
        }
        Util.cmd(s, "bossbar set " + r.bar + " name " + Util.text("Mission complete - returning...", "green"));
        r.state = END;
        r.until = now + 100;
    }

    static int order(String g) {
        return "S".equals(g) ? 3 : "A".equals(g) ? 2 : "B".equals(g) ? 1 : 0;
    }

    /** Failure / quit: no reward. */
    private static void end(MinecraftServer s, Run r, ServerPlayer p, String why) {
        if (p != null) Util.say(p, why);
        home(s, r, p);
        cleanup(s, r);
        RUNS.remove(r.id);
    }

    private static void home(MinecraftServer s, Run r, ServerPlayer p) {
        if (p != null && p.isAlive()) {
            Util.cmd(s, "execute in " + r.origDim + " run tp " + r.pname + " " + Util.num(r.ox) + " " + Util.num(r.oy) + " " + Util.num(r.oz));
        }
    }

    private static void cleanup(MinecraftServer s, Run r) {
        for (Bot b : r.bots) Bridge.despawn(s, b.name);
        r.bots.clear();
        Util.cmd(s, "bossbar remove " + r.bar);
    }
}
