# Universe Freeplay (UnstableStory add-on)

Needs: Minecraft 1.21.11 (Fabric), Fabric API, UnstableStory 1.0.17, VexBot, Unstable Generation.

Commands: /universe (menu)  /universe tier <n>  /universe ranks  /universe kits  /universe top  /universe quit
Testing: /universe debug rank <0-4>   (turn off with allowDebug=false in the config)

Ranks: Human -> Planet -> Star -> Galaxy -> Universe (leader).
Clear all 5 missions of your rank once to move up. Universe is the leader tier: big battles, repeatable, /universe top.

## VexBot kits to make (editable in config/universefreeplay.json)
For each of: human, planet, star, galaxy, universe
  <rank>_grunt   basic enemy
  <rank>_elite   tougher enemy
  <rank>_boss    boss
e.g. human_grunt, human_elite, human_boss, planet_grunt ... universe_boss  (15 kits)
Tip: to start small, edit the config so every rank uses the same 3 kits.
