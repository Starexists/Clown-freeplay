# Universe Freeplay (UnstableStory add-on)

Needs: Minecraft 1.21.11 (Fabric), Fabric API, UnstableStory 1.0.17, VexBot, Unstable Generation.

Journal (scrolls with the mouse wheel / touch): /universe, the Quick Actions key (see Controls), or the pause-menu button.
Commands: /universe  /universe tier <n>  /universe ranks  /universe info  /universe top  /universe kits  /universe quit
Testing: /universe debug rank <0-4>   (turn off with allowDebug=false in the config)

Ranks: Human -> Planet -> Star -> Galaxy -> Universe (leader).
Clear all 5 missions of your rank once to move up. Universe is the leader tier: big battles, repeatable, /universe top.

## VexBot kits to make (5 total, one per rank)
  human   planet   star   galaxy   universe
Every enemy at a rank uses that rank's kit. /universe kits shows which are missing.
If you used the older version, delete config/universefreeplay.json so the new defaults are written.
