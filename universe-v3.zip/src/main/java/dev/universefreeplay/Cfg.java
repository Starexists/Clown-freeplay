package dev.universefreeplay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/universefreeplay.json - ranks and missions. Edit it freely (kit names, sites, waves...). */
public final class Cfg {
    public static final class Rank {
        public String name = "Rank";
        public Rank() {}
        Rank(String n) { name = n; }
    }

    public static final class Enemy {
        public String kit = "human";
        public int count = 1;
        public Enemy() {}
        Enemy(String k, int c) { kit = k; count = c; }
    }

    public static final class Wave {
        public String title = "";
        public List<Enemy> enemies = new ArrayList<>();
    }

    public static final class Mission {
        public String id = "";
        public String title = "";
        public String summary = "";
        /** A UnstableStory site name (e.g. CIV_MERCHANT) or PLAINS. */
        public String site = "PLAINS";
        /** Which rank this mission belongs to: 0 Human, 1 Planet, 2 Star, 3 Galaxy, 4 Universe. */
        public int tier = 0;
        /** Seconds. */
        public int timeLimit = 300;
        public boolean big = false;
        public int dx = 0;
        public int dz = 0;
        public List<Wave> waves = new ArrayList<>();
    }

    public boolean allowDebug = true;
    public String note = "Clear every mission of your rank once to rank up. Site = UnstableStory build name or PLAINS. Kits are VexBot kits.";
    public List<Rank> ranks = new ArrayList<>();
    public List<Mission> missions = new ArrayList<>();

    private static Cfg INSTANCE;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static Cfg get() {
        if (INSTANCE == null) INSTANCE = defaults();
        return INSTANCE;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("universefreeplay.json");
    }

    static void load() {
        Path p = file();
        try {
            if (Files.exists(p)) {
                INSTANCE = GSON.fromJson(Files.readString(p), Cfg.class);
            } else {
                INSTANCE = defaults();
                Files.writeString(p, GSON.toJson(INSTANCE));
            }
        } catch (Exception e) {
            Util.LOG.warn("Could not read universefreeplay.json, using defaults", e);
            INSTANCE = defaults();
        }
        if (INSTANCE == null) INSTANCE = defaults();
        if (INSTANCE.ranks == null || INSTANCE.ranks.isEmpty()) INSTANCE.ranks = defaults().ranks;
        if (INSTANCE.missions == null) INSTANCE.missions = new ArrayList<>();
    }

    static Mission mission(String id) {
        for (Mission m : get().missions) if (m.id.equalsIgnoreCase(id)) return m;
        return null;
    }

    static List<String> missionIds() {
        List<String> l = new ArrayList<>();
        for (Mission m : get().missions) l.add(m.id);
        return l;
    }

    static int lastTier() {
        return get().ranks.size() - 1;
    }

    static String rankName(int i) {
        List<Rank> rs = get().ranks;
        return rs.get(Math.max(0, Math.min(i, rs.size() - 1))).name;
    }

    static int countInTier(int tier) {
        int n = 0;
        for (Mission m : get().missions) if (m.tier == tier) n++;
        return n;
    }

    static int clearedInTier(Data.Rec rec, int tier) {
        int n = 0;
        for (Mission m : get().missions) if (m.tier == tier && rec.clears.getOrDefault(m.id, 0) > 0) n++;
        return n;
    }

    // ---- defaults -------------------------------------------------------

    private static final String[] T = {"human", "planet", "star", "galaxy", "universe"};

    private static Mission gen(String id, String title, String summary, String site, int tier, int nWaves, boolean boss, boolean big) {
        Mission m = new Mission();
        m.id = id; m.title = title; m.summary = summary; m.site = site;
        m.tier = tier; m.big = big;
        m.timeLimit = 240 + tier * 90 + nWaves * 60;
        for (int i = 0; i < nWaves; i++) {
            Wave w = new Wave();
            boolean last = boss && i == nWaves - 1;
            w.title = last ? "FINAL WAVE" : "Wave " + (i + 1);
            int n = 3 + tier * 2 + i * 2 + (last ? 3 : 0);
            w.enemies.add(new Enemy(T[tier], Math.min(20, n)));
            m.waves.add(w);
        }
        return m;
    }

    private static Cfg defaults() {
        Cfg c = new Cfg();
        for (String r : new String[]{"Human", "Planet", "Star", "Galaxy", "Universe"}) c.ranks.add(new Rank(r));
        List<Mission> l = c.missions;

        // Human
        l.add(gen("h_temple", "Lakerek's Temple", "Clear the temple.", "LAKEREK_TEMPLE", 0, 2, false, false));
        l.add(gen("h_monument", "Ocean Monument Echo", "Fight at the monument.", "OCEAN_MONUMENT_ECHO", 0, 2, false, false));
        l.add(gen("h_caves", "Kingdom of the Caves", "Hold the caves.", "CIV_CAVES", 0, 3, false, false));
        l.add(gen("h_merchant", "Merchant City Fight", "Defend the merchants.", "CIV_MERCHANT", 0, 3, false, false));
        l.add(gen("h_stasis", "Mafia Stasis Tunnels", "Human final exam.", "MAFIA_STASIS", 0, 3, true, false));

        // Planet
        l.add(gen("p_mafia", "Mafia City Streets", "Take the streets.", "MAFIA_CITY", 1, 2, false, false));
        l.add(gen("p_highwater", "Highwater City", "Fight through Highwater.", "CIV_HIGHWATER", 1, 2, false, false));
        l.add(gen("p_steam", "Steampunk City", "Gears and guns.", "CIV_STEAMPUNK", 1, 3, false, false));
        l.add(gen("p_capital", "Capital City", "Hold the Capital.", "CIV_CAPITOL", 1, 3, false, false));
        l.add(gen("p_lawhq", "Law HQ and Prison", "Planet final exam.", "LAW_HQ", 1, 3, true, false));

        // Star
        l.add(gen("s_pirate", "Pirate City", "Storm the ring city.", "LAW_PIRATE_BASE", 2, 3, false, false));
        l.add(gen("s_cannon", "The Law's Cannon Island", "Silence the cannon.", "LAW_CANNON", 2, 3, false, false));
        l.add(gen("s_orbital", "Wemmbu's Orbitals", "Fight under the orbitals.", "ORBITAL_DEFENSE", 2, 3, false, false));
        l.add(gen("s_underworld", "The Soulkeeper's Tower", "Climb the tower.", "UNDERWORLD_TOWER", 2, 3, false, false));
        l.add(gen("s_end", "The Law's End Base", "Star final exam.", "LAW_END_BASE", 2, 4, true, false));

        // Galaxy
        l.add(gen("g_council", "The Northern Council", "Break the council.", "CIV_NORTHERN_COUNCIL", 3, 3, false, false));
        l.add(gen("g_statue", "The 2v1000 Statue", "Defend the statue.", "LAW_STATUE", 3, 3, false, false));
        l.add(gen("g_minute", "MinuteTech's End Base", "Fight on the outer islands.", "MINUTE_END_BASE", 3, 4, false, false));
        l.add(gen("g_gods", "City of Gods", "March on the gods.", "CITY_OF_GODS", 3, 4, false, false));
        l.add(gen("g_null", "The NULL Capital", "Galaxy final exam.", "NULL_CAPITAL", 3, 4, true, false));

        // Universe (leader tier): big battles, repeatable, ranked on /universe top
        l.add(gen("u_arena", "Cosmic Arena", "Open plains, endless pressure.", "PLAINS", 4, 4, true, true));
        l.add(gen("u_capital", "Siege of the Capital", "The great siege.", "CIV_CAPITOL", 4, 4, true, true));
        l.add(gen("u_orbital", "Battle of the Orbitals", "War beneath the orbitals.", "ORBITAL_DEFENSE", 4, 5, true, true));
        l.add(gen("u_gods", "War of the Gods", "The gods fight back.", "CITY_OF_GODS", 4, 5, true, true));
        l.add(gen("u_null", "The Final Universe Battle", "Defeat everything.", "NULL_CAPITAL", 4, 6, true, true));
        return c;
    }
}
