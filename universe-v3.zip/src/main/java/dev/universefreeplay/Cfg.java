package dev.universefreeplay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** config/universefreeplay.json - ranks, missions, empires (kits + skins). Edit it freely. */
public final class Cfg {
    static final int VERSION = 6;

    public static final class Rank {
        public String name = "Rank";
        /** VexBot kit the PLAYER receives when starting a mission of this rank. */
        public String kit = "";
        public Rank() {}
        Rank(String n, String k) { name = n; kit = k; }
    }

    /** A main character: the bot is named after them, wears their skin, and uses their kit. */
    public static final class Character {
        public String name = "";
        public String kit = "";
        public Character() {}
        Character(String name, String kit) { this.name = name; this.kit = kit; }
        static Character of(String pair) {
            int i = pair.indexOf(':');
            return new Character(pair.substring(0, i), pair.substring(i + 1));
        }
    }

    /** An empire: kits for random-named soldiers, plus its named main characters and boss. */
    public static final class Empire {
        public List<String> kits = new ArrayList<>();
        public List<String> elite = new ArrayList<>();
        public Character boss;
        public List<Character> characters = new ArrayList<>();
        public Empire() {}
    }

    public static final class Wave {
        public String title = "";
        /** Total enemies in the wave. */
        public int count = 4;
        /** If true, one of the enemies is the empire's boss. */
        public boolean boss = false;
    }

    public static final class Mission {
        public String id = "";
        public String title = "";
        public String summary = "";
        /** A UnstableStory site name (e.g. CIV_MERCHANT) or PLAINS. */
        public String site = "PLAINS";
        /** Which rank this mission belongs to: 0 Human, 1 Planet, 2 Star, 3 Galaxy, 4 Universe. */
        public int tier = 0;
        /** Empire whose kits the enemies use. Empty = decided by the site. */
        public String empire = "";
        /** Seconds. */
        public int timeLimit = 300;
        public boolean big = false;
        /** Optional offset from the site's entry point. */
        public int dx = 0;
        public int dz = 0;
        public List<Wave> waves = new ArrayList<>();
    }

    public int version = VERSION;
    public boolean allowDebug = true;
    public boolean giveRankKit = true;
    public boolean dressBots = true;
    public boolean useCharacters = true;
    public String note = "Soldiers get random names from randomNames (skin = that name) and their empire's kits. Main characters/bosses use their own name, skin and kit. The player gets ranks[].kit when a mission starts.";
    public List<Rank> ranks = new ArrayList<>();
    /** Real Minecraft names for random soldiers. Paste names from NameMC here. */
    public List<String> randomNames = new ArrayList<>();
    public Map<String, Empire> empires = new LinkedHashMap<>();
    public Map<String, String> siteEmpire = new LinkedHashMap<>();
    public List<Mission> missions = new ArrayList<>();

    private static Cfg INSTANCE;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static Cfg get() {
        if (INSTANCE == null) INSTANCE = defaults();
        return INSTANCE;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("universefreeplay.json");
    }

    static void load() {
        Path p = file();
        try {
            if (Files.exists(p)) {
                Cfg c = GSON.fromJson(Files.readString(p), Cfg.class);
                if (c == null || c.version != VERSION) {
                    Files.move(p, p.resolveSibling("universefreeplay.json.old"), StandardCopyOption.REPLACE_EXISTING);
                    INSTANCE = defaults();
                    Files.writeString(p, GSON.toJson(INSTANCE));
                    Util.LOG.info("Old universefreeplay.json moved to .old, new defaults written");
                } else {
                    INSTANCE = c;
                }
            } else {
                INSTANCE = defaults();
                Files.writeString(p, GSON.toJson(INSTANCE));
            }
        } catch (Exception e) {
            Util.LOG.warn("Could not read universefreeplay.json, using defaults", e);
            INSTANCE = defaults();
        }
        Cfg d = defaults();
        if (INSTANCE.ranks == null || INSTANCE.ranks.isEmpty()) INSTANCE.ranks = d.ranks;
        if (INSTANCE.missions == null) INSTANCE.missions = new ArrayList<>();
        if (INSTANCE.empires == null || INSTANCE.empires.isEmpty()) INSTANCE.empires = d.empires;
        if (INSTANCE.siteEmpire == null) INSTANCE.siteEmpire = d.siteEmpire;
        if (INSTANCE.randomNames == null || INSTANCE.randomNames.isEmpty()) INSTANCE.randomNames = d.randomNames;
    }

    static Mission mission(String id) {
        for (Mission m : get().missions) if (m.id.equalsIgnoreCase(id)) return m;
        return null;
    }

    static List<String> missionIds() {
        List<String> l = new ArrayList<>();
        for (Mission m : get().missions) l.add(m.id);
        return l;
    }

    static int lastTier() {
        return get().ranks.size() - 1;
    }

    static String rankName(int i) {
        List<Rank> rs = get().ranks;
        return rs.get(Math.max(0, Math.min(i, rs.size() - 1))).name;
    }

    static String rankKit(int i) {
        List<Rank> rs = get().ranks;
        return rs.get(Math.max(0, Math.min(i, rs.size() - 1))).kit;
    }

    static int countInTier(int tier) {
        int n = 0;
        for (Mission m : get().missions) if (m.tier == tier) n++;
        return n;
    }

    static int clearedInTier(Data.Rec rec, int tier) {
        int n = 0;
        for (Mission m : get().missions) if (m.tier == tier && rec.clears.getOrDefault(m.id, 0) > 0) n++;
        return n;
    }

    static String empireId(Mission m) {
        if (m.empire != null && !m.empire.isEmpty()) return m.empire.toUpperCase(Locale.ROOT);
        String e = get().siteEmpire.get(m.site.toUpperCase(Locale.ROOT));
        return e != null ? e : "LAW";
    }

    static Empire empire(Mission m) {
        Empire e = get().empires.get(empireId(m));
        if (e == null && !get().empires.isEmpty()) e = get().empires.values().iterator().next();
        return e == null ? new Empire() : e;
    }

    // ---- defaults -------------------------------------------------------

    private static final String[] T = {"human", "planet", "star", "galaxy", "universe"};

    private static Mission gen(String id, String title, String summary, String site, String empire, int tier, int nWaves, boolean boss, boolean big) {
        Mission m = new Mission();
        m.id = id; m.title = title; m.summary = summary; m.site = site; m.empire = empire;
        m.tier = tier; m.big = big;
        m.timeLimit = 240 + tier * 90 + nWaves * 60;
        for (int i = 0; i < nWaves; i++) {
            Wave w = new Wave();
            boolean last = boss && i == nWaves - 1;
            w.title = last ? "FINAL WAVE" : "Wave " + (i + 1);
            w.count = Math.min(14, 3 + tier + i * 2 + (last ? 2 : 0));
            w.boss = last;
            m.waves.add(w);
        }
        return m;
    }

    private static void emp(Cfg c, String id, String[] kits, String[] elite, String boss, String... chars) {
        Empire e = new Empire();
        e.kits = new ArrayList<>(Arrays.asList(kits));
        e.elite = new ArrayList<>(Arrays.asList(elite));
        e.boss = boss == null || boss.isEmpty() ? null : Character.of(boss);
        for (String ch : chars) e.characters.add(Character.of(ch));
        c.empires.put(id, e);
    }

    private static void site(Cfg c, String empire, String site) {
        c.siteEmpire.put(site, empire);
    }

    private static Cfg defaults() {
        Cfg c = new Cfg();
        String[] names = {"Human", "Planet", "Star", "Galaxy", "Universe"};
        for (int i = 0; i < names.length; i++) c.ranks.add(new Rank(names[i], T[i]));

        // Random soldiers use names pulled from UnstableStory's own cast (edit freely, or paste NameMC names).
        c.randomNames.addAll(Arrays.asList("Wemmbu", "SargeLAW", "Lomedy", "JumperWho", "Spoke", "Mapicc", "Jamato",
                "Ashswag", "FlameFrags", "Jaden_MAN", "Prince", "Yungy", "Reina", "Swight", "Evbo", "Arachn1d",
                "Saparata", "ShoeBilly", "Lakerek", "ParrotX2", "Theo", "MinuteTech", "EnderDragonPeanut", "ClownPierce"));

        // Empires: kits come from your VexBot kit folder.
        emp(c, "MAFIA", new String[]{"mafia", "mafiairon", "mafia_notrim", "mafiacop"}, new String[]{"mafiadia", "mafia_kit_upgraded"},
                "Ashswag:Ashswag", "FlameFrags:FlameMafiaMesa", "Wemmbu:WemmbuMesaMafia", "Jaden_MAN:Jaden_MAN");
        emp(c, "LAW", new String[]{"law", "lawsoliderHQ", "lawsoliderHQ_2", "Law20"}, new String[]{"Lawdia", "dialaw", "nethlaw", "LawCommander"},
                "SargeLAW:SargeLAW", "Lomedy:lomedy", "JumperWho:JumperWho", "Wemmbu:WemmbuLawFight", "Spoke:Spoke_FightLaw");
        emp(c, "NULL", new String[]{"nullarmy_2", "NullSolider", "null", "NullArmy"}, new String[]{"null_chungie", "NullSolider_2", "nullcommander"},
                "Spoke:SpokeIsHereNull", "Mapicc:MapiccNull", "Jamato:NullJamatoP", "JumperWho:JumperWhoNULL", "Wemmbu:wemmbunull");
        emp(c, "CIV", new String[]{"RoyalArmyCivil", "RoyalArmyCivil_2", "yungyciv", "ReinaCivil"}, new String[]{"BountyCivDia", "BountyCivNeth", "WemmbuCivil"},
                "Prince:Prince", "Yungy:yungyciv", "Reina:ReinaCivil_2", "Wemmbu:WemmbuCivil_2");
        emp(c, "BANDIT", new String[]{"Bandit_NORMAL", "bandit", "Normal_bandit", "SwightBanditSMP"}, new String[]{"Bandit_NORMAL_3", "SwightBanditCart"},
                "Swight:swight", "Yungy:yungySwight");
        emp(c, "PIRATES", new String[]{"pirates1", "PiratesBot", "PiratesBot_2"}, new String[]{"PiratesBot_2"},
                "Evbo:Evbo", "Arachn1d:Arachn1d1");
        emp(c, "CINDERCREST", new String[]{"Cindercrest_Soldier", "Cindercrest_Soldier_2"}, new String[]{"Cindercrest_Soldier_3"},
                "Saparata:Saparata_CinderCrest_3", "ShoeBilly:ShoeBilly_CinderCrest", "Lomedy:Lomedy_CinderCrest", "FlameFrags:Flamefrags_CinderCrest");
        emp(c, "CAVES", new String[]{"Cave_Chungy", "Cave_Chungy_2"}, new String[]{"Cave_Chungy_3", "arachnidchungus"},
                "Lakerek:Lakerek", "Arachn1d:Arachn1d_Chungies");
        emp(c, "PARROT", new String[]{"ParrotArmyKit", "ParrotArmyKit_2", "Lawparrotarmy"}, new String[]{"ParrotArmyKit_4", "ParrotBoosferFactory"},
                "ParrotX2:ParrotX2_King", "Theo:TheoBoosferFactory", "Wemmbu:WemmbuBoosferCrew");
        emp(c, "MINUTE", new String[]{"minute_bot", "minutetech", "MinuteTech_2"}, new String[]{"MinuteTech_3", "MinuteTech_4", "minutenull"},
                "MinuteTech:minutenull2");
        emp(c, "GODS", new String[]{"GoWBot", "GoWBot_2", "godofwar"}, new String[]{"TheG0DofWart", "theg0dofwar"},
                "EnderDragonPeanut:EnderDragonPeanut");
        emp(c, "UNDERWORLD", new String[]{"spokepoor", "spokepurgatory", "spokefarlands"}, new String[]{"spokestrong", "SpokeAfterPurgatoryV4"},
                "Spoke:Spoke99Accuracy");
        emp(c, "CLOWN", new String[]{"clownsoldier", "Clown"}, new String[]{"clownpeirce", "ClownPierce"},
                "ClownPierce:ClownPiercet");

        // Which empire (kits) and name prefix each build uses.
        site(c, "CAVES", "LAKEREK_TEMPLE");
        site(c, "PIRATES", "OCEAN_MONUMENT_ECHO");
        site(c, "GODS", "CITY_OF_GODS");
        site(c, "LAW", "ORBITAL_DEFENSE");
        site(c, "MAFIA", "MAFIA_CITY");
        site(c, "MAFIA", "MAFIA_STASIS");
        site(c, "NULL", "NULL_CAPITAL");
        site(c, "CAVES", "CIV_CAVES");
        site(c, "CIV", "CIV_MERCHANT");
        site(c, "CIV", "CIV_HIGHWATER");
        site(c, "CINDERCREST", "CIV_STEAMPUNK");
        site(c, "CIV", "CIV_CAPITOL");
        site(c, "CIV", "CIV_NORTHERN_COUNCIL");
        site(c, "LAW", "LAW_HQ");
        site(c, "LAW", "LAW_REDSTONE_TOWN");
        site(c, "BANDIT", "LAW_SMUGGLERS_PASS");
        site(c, "PIRATES", "LAW_SEA_ENTRANCE");
        site(c, "PIRATES", "LAW_PIRATE_BASE");
        site(c, "LAW", "LAW_CANNON");
        site(c, "LAW", "LAW_STATUE");
        site(c, "PARROT", "LAW_BOOSFER_FACTORY");
        site(c, "LAW", "LAW_BAT_BASE");
        site(c, "PARROT", "LAW_WIND_TRAP");
        site(c, "LAW", "LAW_SPAWN");
        site(c, "LAW", "LAW_END_BASE");
        site(c, "MINUTE", "MINUTE_END_BASE");
        site(c, "UNDERWORLD", "UNDERWORLD_TOWER");

        List<Mission> l = c.missions;
        // Human
        l.add(gen("h_temple", "Lakerek's Temple", "Clear the temple.", "LAKEREK_TEMPLE", "", 0, 2, false, false));
        l.add(gen("h_bat", "B.A.T's Old Base", "Take back the old base.", "LAW_BAT_BASE", "", 0, 2, false, false));
        l.add(gen("h_caves", "Kingdom of the Caves", "Hold the caves.", "CIV_CAVES", "", 0, 3, false, false));
        l.add(gen("h_merchant", "Merchant City Fight", "Defend the merchants.", "CIV_MERCHANT", "", 0, 3, false, false));
        l.add(gen("h_stasis", "Mafia Stasis Tunnels", "Human final exam.", "MAFIA_STASIS", "", 0, 3, true, false));
        // Planet
        l.add(gen("p_mafia", "Mafia City Streets", "Take the streets.", "MAFIA_CITY", "", 1, 2, false, false));
        l.add(gen("p_spawn", "The Law's Spawn", "Fight at the Law's spawn.", "LAW_SPAWN", "", 1, 2, false, false));
        l.add(gen("p_steam", "Steampunk City", "Gears and guns.", "CIV_STEAMPUNK", "", 1, 3, false, false));
        l.add(gen("p_capital", "Capital City", "Hold the Capital.", "CIV_CAPITOL", "", 1, 3, false, false));
        l.add(gen("p_lawhq", "Law HQ and Prison", "Planet final exam.", "LAW_HQ", "", 1, 3, true, false));
        // Star
        l.add(gen("s_pirate", "Pirate City", "Storm the pirate city.", "LAW_PIRATE_BASE", "", 2, 3, false, false));
        l.add(gen("s_wind", "Parrot's Wind Trap", "Spring the trap.", "LAW_WIND_TRAP", "", 2, 3, false, false));
        l.add(gen("s_orbital", "Wemmbu's Orbitals", "Fight under the orbitals.", "ORBITAL_DEFENSE", "", 2, 3, false, false));
        l.add(gen("s_underworld", "The Soulkeeper's Tower", "Climb the tower.", "UNDERWORLD_TOWER", "", 2, 3, false, false));
        l.add(gen("s_end", "The Law's End Base", "Star final exam.", "LAW_END_BASE", "", 2, 4, true, false));
        // Galaxy
        l.add(gen("g_council", "The Northern Council", "Break the council.", "CIV_NORTHERN_COUNCIL", "", 3, 3, false, false));
        l.add(gen("g_statue", "The 2v1000 Statue", "Defend the statue.", "LAW_STATUE", "", 3, 3, false, false));
        l.add(gen("g_minute", "MinuteTech's End Base", "Fight on the outer islands.", "MINUTE_END_BASE", "", 3, 4, false, false));
        l.add(gen("g_gods", "City of Gods", "March on the gods.", "CITY_OF_GODS", "", 3, 4, false, false));
        l.add(gen("g_null", "The NULL Capital", "Galaxy final exam.", "NULL_CAPITAL", "", 3, 4, true, false));
        // Universe (leader tier)
        l.add(gen("u_arena", "Cosmic Arena", "Open plains, endless pressure.", "PLAINS", "NULL", 4, 4, true, true));
        l.add(gen("u_capital", "Siege of the Capital", "The great siege.", "CIV_CAPITOL", "", 4, 4, true, true));
        l.add(gen("u_orbital", "Battle of the Orbitals", "War beneath the orbitals.", "ORBITAL_DEFENSE", "", 4, 5, true, true));
        l.add(gen("u_gods", "War of the Gods", "The gods fight back.", "CITY_OF_GODS", "", 4, 5, true, true));
        l.add(gen("u_null", "The Final Universe Battle", "Defeat everything.", "NULL_CAPITAL", "", 4, 6, true, true));
        return c;
    }
}
