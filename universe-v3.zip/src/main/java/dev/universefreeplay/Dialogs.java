package dev.universefreeplay;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * The journal: vanilla dialog screens (1.21.6+). They scroll with the mouse wheel / touch,
 * and need nothing installed on the client. Built as inline SNBT and shown with /dialog show.
 */
final class Dialogs {
    private static final int W = 300;

    private Dialogs() {}

    // ---- SNBT helpers ---------------------------------------------------

    static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char ch : s.toCharArray()) {
            if (ch == '\\') b.append("\\\\");
            else if (ch == '"') b.append("\\\"");
            else if (ch == '\n') b.append("\\n");
            else b.append(ch);
        }
        return b.append('"').toString();
    }

    private static String c(String text, String color) {
        return "{text:" + q(text) + ",color:\"" + color + "\"}";
    }

    private static String cb(String text, String color) {
        return "{text:" + q(text) + ",color:\"" + color + "\",bold:true}";
    }

    private static String list(String... parts) {
        return "[" + String.join(",", parts) + "]";
    }

    private static String plain(String contents) {
        return "{type:\"minecraft:plain_message\",contents:" + contents + ",width:" + W + "}";
    }

    private static String btn(String label, String tooltip, String command) {
        String t = tooltip == null ? "" : ",tooltip:" + tooltip;
        return "{label:" + label + t + ",width:" + W + ",action:{type:\"run_command\",command:" + q(command) + "}}";
    }

    private static String bar(int done, int total) {
        int d = Math.max(0, Math.min(done, total));
        return "[" + "#".repeat(d) + "-".repeat(Math.max(0, total - d)) + "]";
    }

    private static String pretty(String site) {
        if ("PLAINS".equalsIgnoreCase(site)) return "Open plains";
        StringBuilder b = new StringBuilder();
        for (String w : site.toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }

    private static void show(MinecraftServer s, ServerPlayer p, String dialog) {
        Util.cmd(s, "dialog show " + p.getScoreboardName() + " " + dialog);
    }

    private static String back(String command) {
        return "{label:" + q("Back") + ",width:150,action:{type:\"run_command\",command:" + q(command) + "}}";
    }

    // ---- main page: missions of one rank --------------------------------

    static String mainDialog(Data.Rec rec, int tier, boolean busy) {
        Cfg cfg = Cfg.get();
        int last = Cfg.lastTier();
        tier = Math.max(0, Math.min(tier, Math.min(rec.rank, last)));
        int total = Cfg.countInTier(tier);
        int done = Cfg.clearedInTier(rec, tier);

        List<String> head = new ArrayList<>();
        head.add(c("Your rank: ", "gray"));
        head.add(cb(Cfg.rankName(rec.rank), "yellow"));
        head.add(c("\n", "white"));
        if (tier == rec.rank && rec.rank < last) {
            head.add(c("Clear all " + total + " " + Cfg.rankName(tier) + " missions to become " + Cfg.rankName(tier + 1)
                    + ":  " + done + "/" + total + "  " + bar(done, total), "aqua"));
        } else if (tier == last) {
            head.add(c("Leader tier: big battles you can repeat.  Your clears: " + Data.universeClears(rec), "red"));
        } else {
            head.add(c("Showing " + Cfg.rankName(tier) + " missions (practice, no rank progress)", "dark_gray"));
        }

        List<String> body = new ArrayList<>();
        body.add(plain(list(head.toArray(new String[0]))));
        body.add(plain(c("Tap a mission to start. You are teleported to the build and fight waves of enemies. "
                + "Defeat them all before the timer ends.", "gray")));

        List<String> acts = new ArrayList<>();
        for (Cfg.Mission m : cfg.missions) {
            if (m.tier != tier) continue;
            boolean cleared = rec.clears.getOrDefault(m.id, 0) > 0;
            String best = rec.best.get(m.id);
            int enemies = 0;
            for (Cfg.Wave w : m.waves) for (Cfg.Enemy e : w.enemies) enemies += e.count;
            int sec = m.timeLimit;
            String tip = m.summary + "\nBuild: " + pretty(m.site)
                    + "\nWaves: " + m.waves.size() + "   Enemies: " + enemies
                    + "\nTime limit: " + (sec / 60) + ":" + String.format("%02d", sec % 60)
                    + "\n" + (cleared ? "Cleared. Best grade: " + (best == null ? "-" : best) : "Not cleared yet");
            String label = (cleared ? "[x] " : "[ ] ") + m.title + (cleared && best != null ? "   (" + best + ")" : "");
            acts.add(btn(cleared ? c(label, "green") : c(label, "white"), c(tip, "gray"), "universe start " + m.id));
        }
        acts.add(btn(c("Ranks", "yellow"), c("All ranks and your progress", "gray"), "universe ranks"));
        acts.add(btn(c("Leaderboard", "gold"), c("Top players", "gray"), "universe top"));
        acts.add(btn(c("How it works", "aqua"), c("Rules, grades and ranks", "gray"), "universe info"));
        if (busy) acts.add(btn(c("Quit current mission", "red"), c("Leave and return, no progress", "gray"), "universe quit"));

        return "{type:\"minecraft:multi_action\",title:" + cb("Universe Freeplay - " + Cfg.rankName(tier), "light_purple")
                + ",pause:false,columns:1,body:[" + String.join(",", body) + "],actions:[" + String.join(",", acts)
                + "],exit_action:{label:" + q("Close") + ",width:150}}";
    }

    // ---- ranks overview -------------------------------------------------

    static String ranksDialog(Data.Rec rec) {
        int last = Cfg.lastTier();
        List<String> lines = new ArrayList<>();
        lines.add(c("Clear every mission of a rank once to move up.\n\n", "gray"));
        List<String> acts = new ArrayList<>();
        for (int t = 0; t <= last; t++) {
            String name = Cfg.rankName(t);
            String prog = t < last ? Cfg.clearedInTier(rec, t) + "/" + Cfg.countInTier(t) + " cleared"
                    : Data.universeClears(rec) + " big battle clears";
            if (t <= rec.rank) {
                String label = name + " - " + prog + (t == rec.rank ? "   (your rank)" : "");
                acts.add(btn(c(label, t == rec.rank ? "yellow" : "white"), c("Open the " + name + " missions", "gray"), "universe tier " + t));
            } else {
                lines.add(c(name + " - locked. Clear all " + Cfg.rankName(t - 1) + " missions first.\n", "dark_gray"));
            }
        }
        return "{type:\"minecraft:multi_action\",title:" + cb("Ranks", "yellow") + ",pause:false,columns:1,body:["
                + plain(list(lines.toArray(new String[0]))) + "],actions:[" + String.join(",", acts)
                + "],exit_action:" + back("universe") + "}";
    }

    // ---- how it works ---------------------------------------------------

    static String infoDialog() {
        int last = Cfg.lastTier();
        StringBuilder ranks = new StringBuilder();
        for (int t = 0; t <= last; t++) ranks.append(t == 0 ? "" : " > ").append(Cfg.rankName(t));
        String[] paras = {
                "Ranks: " + ranks,
                "1. Pick a mission from your rank. You are teleported to that build (or open plains if it isn't in your world).",
                "2. Enemies come in waves. Defeat every enemy before the timer runs out. If you fall, the mission fails and you return.",
                "3. Clear every mission of your rank once to rank up. The last wave of a mission is the hardest.",
                "4. " + Cfg.rankName(last) + " is the leader tier: big battles you can repeat. Your clears count on the leaderboard.",
                "Grades: S if you finish in under half the time, A under three quarters, B otherwise.",
                "Missions of lower ranks can be replayed any time for practice.",
                "Open this journal any time with /universe, the Quick Actions key, or the pause menu button."
        };
        List<String> body = new ArrayList<>();
        for (int i = 0; i < paras.length; i++) body.add(plain(c(paras[i], i == 0 ? "yellow" : "white")));
        return "{type:\"minecraft:notice\",title:" + cb("How it works", "aqua") + ",pause:false,body:[" + String.join(",", body)
                + "],action:" + back("universe") + "}";
    }

    // ---- leaderboard ----------------------------------------------------

    static String topDialog(List<Data.Rec> all) {
        List<Data.Rec> l = new ArrayList<>();
        for (Data.Rec r : all) if (r.rank > 0 || Data.universeClears(r) > 0) l.add(r);
        l.sort(Comparator.<Data.Rec>comparingInt(r -> r.rank).reversed()
                .thenComparing(Comparator.<Data.Rec>comparingInt(Data::universeClears).reversed()));
        List<String> body = new ArrayList<>();
        if (l.isEmpty()) {
            body.add(plain(c("Nobody has ranked up yet.", "gray")));
        } else {
            int n = 0;
            for (Data.Rec r : l) {
                if (++n > 10) break;
                body.add(plain(list(c(n + ". ", "gray"), c(r.name.isEmpty() ? "?" : r.name, "white"),
                        c("  -  " + Cfg.rankName(r.rank) + ", " + Data.universeClears(r) + " big battle clears", "gray"))));
            }
        }
        return "{type:\"minecraft:notice\",title:" + cb("Leaderboard", "gold") + ",pause:false,body:[" + String.join(",", body)
                + "],action:" + back("universe") + "}";
    }

    // ---- entry points ---------------------------------------------------

    static void main(MinecraftServer s, ServerPlayer p, int tier) {
        Data.Rec rec = Data.rec(p.getUUID());
        rec.name = p.getScoreboardName();
        show(s, p, mainDialog(rec, tier, Manager.busy(p.getUUID())));
    }

    static void ranks(MinecraftServer s, ServerPlayer p) {
        show(s, p, ranksDialog(Data.rec(p.getUUID())));
    }

    static void info(MinecraftServer s, ServerPlayer p) {
        show(s, p, infoDialog());
    }

    static void top(MinecraftServer s, ServerPlayer p) {
        show(s, p, topDialog(Data.all()));
    }

    static void kits(MinecraftServer s, ServerPlayer p) {
        String st = Bridge.status();
        if (st != null) { Util.say(p, st); return; }
        List<String> needed = new ArrayList<>();
        for (Cfg.Mission m : Cfg.get().missions)
            for (Cfg.Wave w : m.waves)
                for (Cfg.Enemy e : w.enemies)
                    if (!needed.contains(e.kit)) needed.add(e.kit);
        Util.say(p, "VexBot kits the missions use:");
        for (String k : needed) {
            boolean ok = Bridge.kitExists(s, k);
            p.sendSystemMessage(Component.literal((ok ? "\u00a7a  ready  " : "\u00a7c  MISSING  ") + k));
        }
    }
}
